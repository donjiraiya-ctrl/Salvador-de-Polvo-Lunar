# Public Release / Rights Notice

This repository is published for technical review, competition transparency, and
engineering discussion.

Unless a separate license is expressly added to this repository, publication does
**not** grant a license to manufacture, commercialize, sublicense, or otherwise exploit
the concept or its associated files.

The repository is a Phase 1 engineering concept and is not flight-qualified hardware.

For permissions beyond review and discussion, contact the project owner.
