# Motion-Assisted Lunar Dust Mitigation and Resistive Grounding Interface

A Phase 1 preliminary engineering concept for reducing lunar-regolith contamination
and controlling electrostatic charge at an EVA interface.

## Concept

The system combines two passive functions:

1. **Motion-assisted dust mitigation** — normal astronaut movement mechanically drives
   a compliant wiper/cam mechanism that clears loose dust from a designated interface
   before contact.
2. **Controlled resistive grounding** — a high-value series-resistance path provides
   a controlled discharge route after the cleaning sequence and before structural
   engagement.

The baseline concept requires **no battery, motor, or continuous electrical power**.

### Operating sequence

**Motion → Clean → Resistive contact → Structural engagement**

The mechanical and electrical paths are intentionally separated.

## Preliminary electrical baseline

- Total resistance: **525 MΩ**
- Architecture: **35 × 15 MΩ series elements**
- Current at 100 kV: **190.48 µA**
- Fraction of a 1 mA reference limit: **19.05%**
- Continuous electrical power: **0 W**
- 100 kV point-value dissipation: **19.05 W**, decaying with the discharge
- Preliminary per-element voltage: **2.857 kV idealized**
- Preferred preliminary element working-voltage target: **≥5 kV**

These are Phase 1 engineering calculations, not flight qualification results.

## Packaging and human factors

The final concept uses a preliminary **60 × 45 × 25 mm external module envelope**.
The wearer-facing interface is intended to contain only a flexible conductor and
compliant strain relief; the rigid module is kept outside the occupant-facing volume.

The design still requires Phase 2 verification for glove insertion force, alignment,
mobility, snag hazards, thermal response, dust performance, environmental durability,
and suit integration.

## What is included

- `docs/` — essential concept and engineering documents
- `cad/` — preliminary STEP geometry
- `drawings/` — dimensioned/conceptual technical drawings
- `data/` — BOM, electrical data, and risk matrix in CSV form

## Verification status

**Phase 1 concept — not flight qualified.**

No claim is made here that the system has been tested in lunar vacuum, lunar regolith,
or a flight-like EVA suit environment. Dust-reduction performance remains a verification
target rather than a demonstrated percentage.

## AI disclosure

AI tools were used as an engineering-assistance and documentation aid during concept
development. Human review and engineering judgment remain necessary for requirements
interpretation, calculations, design decisions, verification, and any future hardware
development.

## Public-release note

This repository intentionally contains only the technical material needed to explain
and review the concept. Internal working files, drafts, submission packaging, and
private project material are not included.

## Status

**Preliminary / Phase 1 — Concept for further engineering and testing.**
